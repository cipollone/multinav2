# To re-execute, just change path of --params file
#   to the run-options.yaml file in this directory
poetry run python -m multinav train --params /tmp/tmpo4yrlrwg-run-options.yaml